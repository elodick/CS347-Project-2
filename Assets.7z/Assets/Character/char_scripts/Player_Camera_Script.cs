﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Camera_Script : MonoBehaviour
{

    public Transform player_Cowboy;

    private void FixedUpdate()
    {
        transform.position = new Vector3(player_Cowboy.position.x, player_Cowboy.position.y, transform.position.z);

    }

}
