﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[RequireComponent(typeof(Rigidbody2D))]
public class CharController : MonoBehaviour
{
    private float horizontalInput = 0;
    private float verticalInput = 0;
    public int movementSpeed;
    [SerializeField]
    Rigidbody2D iteboy_sprite;

    void start()
    {
        iteboy_sprite = this.GetComponent<Rigidbody2D>();
    }
    void Update()
    {
        getPlayerInput();
        Move();
    }
    private void getPlayerInput()
    {
        horizontalInput = Input.GetAxisRaw("Horizontal");
        verticalInput = Input.GetAxisRaw("Vertical");
    
    }
    void Move()
    {
        Vector3 directionVector = new Vector3(horizontalInput, verticalInput, 0);
        iteboy_sprite.velocity = directionVector.normalized * movementSpeed;
    }
}